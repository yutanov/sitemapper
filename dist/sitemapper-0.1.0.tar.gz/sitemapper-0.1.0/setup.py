# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sitemapper']

package_data = \
{'': ['*']}

install_requires = \
['aiofile>=3.7.4,<4.0.0',
 'aiohttp>=3.8.1,<4.0.0',
 'asyncio>=3.4.3,<4.0.0',
 'prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['sitemapper = sitemapper.run:main']}

setup_kwargs = {
    'name': 'sitemapper',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'yutanov',
    'author_email': 'utanov@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
